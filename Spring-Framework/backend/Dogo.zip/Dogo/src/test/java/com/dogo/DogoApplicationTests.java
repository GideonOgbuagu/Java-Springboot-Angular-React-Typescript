package com.dogo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DogoApplicationTests {

	@Test
	void contextLoads() {
	}

}
