package com.securewebapp.auth;

public class MyPasswordEncoderFactory {

}
