export class Places {
    id: number;
    city: string;
    country: string;
    description: string;
}
