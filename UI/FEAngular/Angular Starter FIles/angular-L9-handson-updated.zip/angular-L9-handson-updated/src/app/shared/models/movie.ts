export class Movie {
    id: number;
    title: string;
    director: string;
    image_url: string;
}