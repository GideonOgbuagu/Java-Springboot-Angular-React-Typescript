import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Mr. Bigglesworth';
  city = 'San Jose';
  tagLine = 'This is my unique Tagline';
  aboutMe = 'I am a software developer training with Apprentice Now. The training is 8 weeks long and It has been fun. Looking forward to completing the training and hopefully get hired. Thank you';

}
